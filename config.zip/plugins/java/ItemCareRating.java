package com.socotra.deployment.customer;

import com.socotra.coremodel.RatingItem;
import com.socotra.coremodel.RatingSet;
import com.socotra.platform.tools.ULID;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public class ItemCareRating implements RatePlugin {


    private RatingItem calculatePremium(BigDecimal premium, ULID coverageLocator, BigDecimal discountAmountPercentage) {


        BigDecimal discountAmountMultiplier = discountAmountPercentage.divide(BigDecimal.valueOf(100));
        BigDecimal discountAmount = premium.multiply(discountAmountMultiplier);
        BigDecimal updatedPremium = premium.subtract(discountAmount);

        return RatingItem.builder()
                .elementLocator(coverageLocator)
                .chargeType(ChargeType.premium)
                .rate(updatedPremium)
                .build();
    }

    @Override
    public RatingSet rate(ItemCareQuoteRequest request) {

        BigDecimal discountAmountPercentage = request.quote().data().discountAmount() != null
                ? request.quote().data().discountAmount()
                : BigDecimal.ZERO;

        String discountTerm        = request.quote().data().discountTerm();
        String discountType        = request.quote().data().discountType();
        Integer periodOfCover      = request.quote().data().periodOfCover();

        List<RatingItem> ratingItems = new ArrayList<>();

        //Premium loop
        for(Item item : request.quote().items()) {

            if (item.accidentalDamage() != null) {
                ULID coverageLocator = item.accidentalDamage().locator();
                BigDecimal premium = item.accidentalDamage().data().premium();
                ratingItems.add(calculatePremium(premium,coverageLocator,discountAmountPercentage));

            }
        }

        return RatingSet.builder()
                .ok(true)
                .ratingItems(ratingItems)
                .build();
    }

    @Override
    public RatingSet rate(ItemCareRequest request) {

        List<RatingItem> ratingItems = new ArrayList<>();

        // Only rate when segment is present
        if (request.segment().isPresent()) {


            BigDecimal discountAmountPercentage = request.segment().get().data().discountAmount() != null
                    ? request.segment().get().data().discountAmount()
                    : BigDecimal.ZERO;

            String discountTerm        = request.segment().get().data().discountTerm();
            String discountType        = request.segment().get().data().discountType();
            Integer periodOfCover      = request.segment().get().data().periodOfCover();

            //Premium loop
            for(Item item : request.segment().get().items()) {

                if (item.accidentalDamage() != null) {
                    ULID coverageLocator = item.accidentalDamage().locator();
                    BigDecimal premium = item.accidentalDamage().data().premium();
                    ratingItems.add(calculatePremium(premium,coverageLocator,discountAmountPercentage));

                }
            }
        }

        return RatingSet.builder()
                .ok(true)
                .ratingItems(ratingItems)
                .build();
    }

}