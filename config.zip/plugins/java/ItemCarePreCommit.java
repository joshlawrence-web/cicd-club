package com.socotra.deployment.customer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.Instant;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.Optional;

public class ItemCarePreCommit implements PreCommitPlugin {

    protected final Logger logger = LoggerFactory.getLogger(getClass());

    @Override
    public ItemCareQuote preCommit(ItemCareQuoteRequest request) {

        ItemCareQuote originalQuote = request.quote();

        // Current UTC date-time
        OffsetDateTime currentUtc = OffsetDateTime.now(ZoneOffset.UTC);

        // Calculate actual start time
        int newBusinessWaitPeriodInDays = originalQuote.data().newBusinessWaitPeriod();
        OffsetDateTime startDateTime = currentUtc.plusDays(newBusinessWaitPeriodInDays);
        Instant startInstant = startDateTime.toInstant();
        Optional<Instant> startOptional = Optional.of(startInstant);

        // Calculate actual end time
        int periodOfCover = originalQuote.data().periodOfCover();
        OffsetDateTime endDateTime = startDateTime.plusMonths(periodOfCover);
        Instant endInstant = endDateTime.toInstant();
        Optional<Instant> endOptional = Optional.of(endInstant);


            // Build updated quote using pre-calculated Optionals
            ItemCareQuote updatedQuote = originalQuote.toBuilder()
                    .startTime(startOptional)
                    .endTime(endOptional)
                    .timezone("America/Phoenix")
                    .build();
        return updatedQuote;
    }


    @Override
    public ItemCareSegment preCommit(ItemCareRequest request) {

        ItemCareSegment updatedItemCare = request.segment();


        return updatedItemCare;
    }


}